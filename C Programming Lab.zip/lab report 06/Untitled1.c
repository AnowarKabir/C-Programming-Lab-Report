#include<stdio.h>
 void main()
 {
     char str[50],str_1[50],ch ,ch_2;
     int i ,j ,k ,counter=0;
     gets(str);
     for(i=0;i<strlen(str);i++){
            ch = str[i] ;
            str_1[i] = str[i];
            for(j=0;j<strlen(str);j++){
                if(ch==str[j]){
                    counter++;
                }
           }
        printf("%c occur in %d times\n",ch,counter);
        counter = 0 ;
}     }
