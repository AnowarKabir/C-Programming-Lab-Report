#include<stdio.h>
main()
{
char str[8];
int i;
gets(str);
for(i=3;i<=6;i++)
printf("%c",str[i]);



}
