#include<stdio.h>
main()
{
int i,j,fact,n, b=1;
float sum=1.0,temp;
scanf("%d",&n);
for(i=1;i<n;i++)
{
fact=1;
for(j=i;j>=1;j--)
fact=fact*j;
temp=(float)b/fact;
sum+=temp;
}
printf("%.2f",sum);
}
